CREATE VIEW SELECT_WPAY
  AS
    SELECT *
    FROM Worker
    WHERE WorkerName = (SELECT system_user)
go

