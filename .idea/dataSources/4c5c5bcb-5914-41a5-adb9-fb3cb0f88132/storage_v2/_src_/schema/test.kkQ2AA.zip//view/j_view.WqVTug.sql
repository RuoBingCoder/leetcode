create view j_view as
  select `test`.`j`.`JNO` AS `JNO`, `test`.`j`.`JNAME` AS `JNAME`, `test`.`j`.`CITY` AS `CITY`
  from `test`.`j`;

