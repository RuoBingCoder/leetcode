create view spj_view as
  select `test`.`spj`.`SNO` AS `SNO`,
         `test`.`spj`.`PNO` AS `PNO`,
         `test`.`spj`.`JNO` AS `JNO`,
         `test`.`spj`.`QTY` AS `QTY`
  from `test`.`spj`;

