create view p_view as
  select `test`.`p`.`PNO`    AS `PNO`,
         `test`.`p`.`PNAME`  AS `PNAME`,
         `test`.`p`.`COLOR`  AS `COLOR`,
         `test`.`p`.`WEIGHT` AS `WEIGHT`
  from `test`.`p`;

