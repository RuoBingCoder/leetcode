create view vsp as
  select `test`.`spj`.`SNO` AS `SNO`, `test`.`spj`.`PNO` AS `PNO`, `test`.`spj`.`QTY` AS `QTY`
  from `test`.`spj`
         join `test`.`j`
  where ((`test`.`spj`.`JNO` = `test`.`j`.`JNO`) and (`test`.`j`.`JNAME` = '三建'));

