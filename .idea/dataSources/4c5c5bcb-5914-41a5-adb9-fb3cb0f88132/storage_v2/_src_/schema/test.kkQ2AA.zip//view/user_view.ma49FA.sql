create view user_view as
  select `test`.`user`.`id` AS `id`, `test`.`user`.`email` AS `email`, `test`.`user`.`name` AS `name`
  from `test`.`user`;

