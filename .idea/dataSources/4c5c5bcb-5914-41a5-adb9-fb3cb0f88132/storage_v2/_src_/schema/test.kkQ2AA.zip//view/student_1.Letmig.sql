create view student_1 as
  select `test`.`student`.`SNO`       AS `SNO`,
         `test`.`student`.`SNAME`     AS `SNAME`,
         `test`.`student`.`SAGE`      AS `SAGE`,
         `test`.`student`.`SEC`       AS `SEC`,
         `test`.`student`.`SADRESS`   AS `SADRESS`,
         `test`.`student`.`SCLASSNUM` AS `SCLASSNUM`
  from `test`.`student`;

