create view s_view as
  select `test`.`s`.`SNO`    AS `SNO`,
         `test`.`s`.`SNAME`  AS `SNAME`,
         `test`.`s`.`STATUS` AS `STATUS`,
         `test`.`s`.`CITY`   AS `CITY`
  from `test`.`s`;

